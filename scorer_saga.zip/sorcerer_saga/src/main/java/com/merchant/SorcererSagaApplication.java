package com.merchant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SorcererSagaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SorcererSagaApplication.class, args);
	}

}

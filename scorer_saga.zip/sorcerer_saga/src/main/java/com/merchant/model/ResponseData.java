package com.merchant.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ResponseData {
    private BigDecimal average;
}
